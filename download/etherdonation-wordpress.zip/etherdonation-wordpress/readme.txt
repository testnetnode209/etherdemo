=== Ethereum Donation Plugin ===
Contributors: alexss23
Donate link: https://etherdonation.com
Tags: ethereum, eth, donation, donations, wordpress donations, donation plugin, wordpress donation plugin,
wp donation, ecommerce, wordpress ecommerce, e-commerce, commerce, fundraising, fundraiser, crowdfunding,
giving, charity, gift, gifts, donate, cryptocurrency, crypto, blockchain, payment, payments
Requires at least: 3.0
Tested up to: 4.8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Collect more Ethereum (ETH) donations online with WordPress plugin.

== Description ==

Accept Ethereum (ETH) donations online with WordPress plugin. Let your users
make transactions with MetaMask. Simple and free.

= Usage =

After Installing and Activating the plugin, go to WordPress Admin Dashboard, choose

`Settings >> Ethereum Donation`

and setup your Ethereum account.

After saving, just paste the following shortcode at any place your want to show Ethereum Donation link

`[ethereum_donation_link]`

== Installation ==
Installing plugin is just like installing other WordPress plugins.

== Screenshots ==
1. Screenshot of Ethereum Donation Settings page
2. Screenshot of Ethereum Donation Link shortcode (New Post adding)
3. Screenshot of published post with Ethereum Donation Link

== Changelog ==
= 1.0.0 =
* Utilizing basic functionality

== Upgrade Notice ==
You should upgrade the plugin to get more function and faster speed.
